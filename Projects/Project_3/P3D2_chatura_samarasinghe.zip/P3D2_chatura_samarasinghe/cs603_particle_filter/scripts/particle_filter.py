#!/usr/bin/env python3

# Write your code here

"""
Plan

1. Create Motion Model -> predict movements 
    - Key things to check 
        1. How are delta values calculated -> check to how fast they need to calculated

2. Sensor model -> correct movement predictions 
    - Key things
        1. Likelihood matrix
            1. Check if resolution is correct 
            2. Check if aligned with the map properly 
            3. Check if proper distance values are returned

3. Particle filter -> combines two models and resample


4. Visualize the particles 
"""
import rospy
import numpy as np
import math
import sys
import time
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from geometry_msgs.msg import Pose, Twist, PoseArray, Quaternion
from std_msgs.msg import Header
from sensor_msgs.msg import LaserScan
from PIL import Image
import yaml
import os
import pdb
import sys
import rospkg
import cv2


def extract_from_map(image_path, resolution=0.05, save=False, downsample_factor=2):
    """
    Extract likelihood field from map image.
    - resolution: original resolution (m/pixel)
    - downsample_factor: factor to reduce resolution (2 = half size)
    """

    script_dir = os.path.dirname(os.path.abspath(__file__))
    image_path = os.path.join(script_dir, image_path)

    #image_path = os.path.abspath(image_path)

    # Load grayscale image
    map_image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Binarize: obstacles = 0, free = 255
    _, binary_map = cv2.threshold(map_image, 250, 255, cv2.THRESH_BINARY)

    # Clean noise
    kernel = np.ones((3,3), np.uint8)
    cleaned_map = cv2.morphologyEx(binary_map, cv2.MORPH_OPEN, kernel)

    # Compute distance transform
    distance_matrix = cv2.distanceTransform(cleaned_map, cv2.DIST_L2, 5)
    real_world_distances = distance_matrix * resolution

    if downsample_factor > 1:
        new_size = (real_world_distances.shape[1] // downsample_factor,
                    real_world_distances.shape[0] // downsample_factor)
        real_world_distances = cv2.resize(real_world_distances, new_size, interpolation=cv2.INTER_AREA)
        resolution *= downsample_factor  # each pixel now covers a larger area

    # Visualization
    gamma = 0.4
    scaled = (real_world_distances / real_world_distances.max()) ** gamma
    visualization = (scaled * 255).astype(np.uint8)

    if save:
        cv2.imwrite('../maps/metric_map.png', map_image)
        cv2.imwrite('../maps/distance_matrix.png', visualization)

    # cv2.imshow('Likelihood Field', visualization)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    return real_world_distances, resolution



def calculate_distance_squared_from_map(x_pos, y_pos, lookup_matrix, resolution):
    origin_x, origin_y = -10.0, -10.0 # hard coded
    
    # Convert particle pose to map coordinates

    height, width = lookup_matrix.shape

    x_map = int((x_pos - origin_x)/ resolution)
    #x_map = width - int((x_pos - origin_x)/ resolution) -1

    y_map = height - int((y_pos - origin_y)/ resolution) -1 
    #y_map = int((y_pos - origin_y)/ resolution)


    # # Out of bounds check
    # if x_map < 0 or x_map >= width or y_map < 0 or y_map >= height:
    #     return 1e6   
    
    # maps to downsampled res of 2 
    # if x_map < 24 or x_map >= 168 or y_map < 40 or y_map >= 91:
    #     return 4**2   
    
    ## maps to downsampled res of 2 
    if x_map < 24 or x_map >= 168 or y_map < 37 or y_map >= 126:
        return 4**2 

    ## check for middle gap
    elif (x_map > 51 and x_map < 140) and (y_map > 95):
        return 4**2 

    
    # Get expected distance from distance matrix
    expected_distance = lookup_matrix[y_map, x_map]
    
    # Compare with sensor measurements
    return expected_distance ** 2 

    

class ParticleFilter:
    def __init__(self, rate_hz, n_readings, metric_map_yaml):
        # init config 
        rospy.init_node('triton_bot')
        
        # pose 
        self.prev_position =  None
        self.prev_yaw = 0
        self.prev_pose_calc_time = 0
        self.current_position = None
        self.current_yaw = 0
        self.current_pose_calc_time = 0

        # lidar
        self.z_readings = 0
        self.z_max = 0
        self.z_angle_increment = 0
        self.n_readings = n_readings

        # initialized flags
        self.pose_initialized = False 

        # subscribers
        self.odom_reading = rospy.Subscriber('/odom', Odometry, self.odometry_callback)
        self.radar_subscriber = rospy.Subscriber('/scan', LaserScan, self.lidar_callback) 

        # publishers
        #self.pose_array_pub = rospy.Publisher('/particle_cloud', PoseArray, queue_size=10)
        self.pose_array_pub = rospy.Publisher('/particles', PoseArray, queue_size=10)

        #rate_hz = rospy.get_param('~loop_rate', 2)
        self.rate = rospy.Rate(rate_hz)

        self.metric_map_yaml = metric_map_yaml

    
    def initialize_particles(self, n_particles):
        x_min, x_max, y_min, y_max = self.create_map_bounds()
        rospy.loginfo(f"map bounds are x_min: {x_min}, x_max: {x_max}, y_min: {y_min}, y_max: {y_max}")

        theta_min, theta_max = -np.pi, np.pi
        particle_set = []

        # ## completely random
        on_bot_offset= 10
        x_coords = np.random.uniform(low=x_min, high=x_max, size=n_particles-on_bot_offset)
        y_coords = np.random.uniform(low=y_min, high=y_max, size=n_particles-on_bot_offset)
        thetas = np.random.uniform(low=theta_min, high=theta_max, size=n_particles-on_bot_offset)

        ## reduce the randomness
        # offset = 5.0
        # on_bot_offset= 10
        # x_coords = np.random.uniform(low=x_min+offset, high=x_max-offset, size=n_particles-on_bot_offset)
        # y_coords = np.random.uniform(low=y_min+offset, high=y_max-offset, size=n_particles-on_bot_offset)
        # thetas = np.random.uniform(low=theta_min, high=theta_max, size=n_particles-on_bot_offset)
        
        x_coords = np.append(x_coords, np.array([self.current_position.x for _ in range(on_bot_offset)]))
        y_coords = np.append(y_coords,  np.array([self.current_position.y for _ in range(on_bot_offset)]))
        thetas = np.append(thetas, np.array([self.current_yaw for _ in range(on_bot_offset)]))

        # # gaussian on pose
        # x_coords = np.random.normal(self.current_position.x, 0.5, n_particles)
        # y_coords = np.random.normal(self.current_position.y, 0.5, n_particles)
        # thetas = np.random.normal(self.current_yaw, 0.5, n_particles)

        # # testing 
        # x_coords = np.random.normal(self.current_position.x, 0.0, n_particles)
        # y_coords = np.random.normal(self.current_position.y, 0.0, n_particles)
        # thetas = np.random.normal(self.current_yaw, 0.0, n_particles)

        for idx in range(n_particles):
            pose_obj = {"x":x_coords[idx], "y":y_coords[idx], "yaw":thetas[idx]}
            particle_set.append(pose_obj)

        return particle_set
    

    def create_map_bounds(self):
        # Load map metadata

        script_dir = os.path.dirname(os.path.abspath(__file__))
        metric_map_path_yaml = os.path.join(script_dir, self.metric_map_yaml)

        with open(metric_map_path_yaml, 'r') as f:
            data = yaml.safe_load(f)

        image_path = os.path.join(os.path.dirname(metric_map_path_yaml), data['image'])
        resolution = data['resolution']
        origin = data['origin']  # [x, y, theta]

        # Load image dimensions
        img = Image.open(image_path)
        width, height = img.size  # in pixels

        # Compute map bounds in meters
        x_min = origin[0]
        y_min = origin[1]
        x_max = x_min + width * resolution
        y_max = y_min + height * resolution

        return x_min, x_max, y_min, y_max


    def odometry_callback(self, msg):
        current_position = msg.pose.pose.position
        current_orientation = msg.pose.pose.orientation
        current_pose_calc_time = rospy.Time.now()
      
        # Convert quaternion to Euler angles (yaw)
        _, _, current_yaw = euler_from_quaternion(
            [current_orientation.x,
                current_orientation.y,
                current_orientation.z,
                current_orientation.w]
        )

        # initialization
        if not self.pose_initialized:
            self.prev_position = current_position
            self.prev_yaw = current_yaw
            self.prev_pose_calc_time = rospy.Time.now()
            self.pose_initialized = True
            rospy.loginfo(f"Pose initialized position XY :{self.prev_position}, yaw:{self.prev_yaw}")

        else:
            self.current_position = current_position
            self.current_yaw = current_yaw
            self.current_pose_calc_time = current_pose_calc_time
      

    def normalize_angle(self,angle):
        return (angle + math.pi) % (2 * math.pi) - math.pi


    def calculate_motion_deltas(self):
        """
        Returns current pose and calculated delta values
        """   
        # to ensure values are accurate for any rate
        current_position = self.current_position
        current_yaw = self.current_yaw
        prev_position = self.prev_position
        prev_yaw = self.prev_yaw

        dt = (self.current_pose_calc_time - self.prev_pose_calc_time).to_sec()
        #dt = (self.current_pose_calc_time - self.prev_pose_calc_time).to_sec()

        dx = current_position.x - prev_position.x
        dy = current_position.y - prev_position.y

        # updating delta values
        dlta_trans = math.sqrt(dx**2 + dy**2)
        #dlta_rot1 = math.atan2(dy, dx) - prev_yaw
                   # If no real movement, don't compute rot1

        # avoid computing angles for stationary
        if dlta_trans < 1e-4:
            dlta_rot1 = 0.0
        else:
            dlta_rot1 = self.normalize_angle(math.atan2(dy, dx) - prev_yaw)
        
        #dlta_rot2 = current_yaw - prev_yaw - dlta_rot1
        dlta_rot2 = self.normalize_angle(current_yaw - prev_yaw - dlta_rot1)


        # update previous pose
        self.prev_position = current_position
        self.prev_yaw = current_yaw
        self.prev_pose_calc_time = self.current_pose_calc_time

        rospy.loginfo(f"Motion deltas updated. Time diff between prev and current state: {dt}")

        delta_values = {
            "trans": dlta_trans,
            "rot1": dlta_rot1,
            "rot2": dlta_rot2
        }

        pose = {
            "x": current_position.x,
            "y": current_position.y,
            "yaw": current_yaw,
        }

        return delta_values, pose


    def lidar_callback(self, msg):        
        self.z_readings = {}
        front_beam_idx = 0 
        max_offset = 180
        total_beams = len(msg.ranges)
        reading_offset = min(self.n_readings // 2, max_offset)
        
        # Left side: forward to left
        left_side_beams = msg.ranges[front_beam_idx : front_beam_idx + reading_offset]
        
        # Right side: wrap-around from end of scan array
        right_side_beams = msg.ranges[-reading_offset:] 

        # Right beams: negative indices
        for i, z in enumerate(right_side_beams):
            idx = -(reading_offset - i)
            self.z_readings[idx] = {'z_dist': z}

        # Left beams: positive indices
        for i, z in enumerate(left_side_beams):
            idx = i + 1
            self.z_readings[idx] = {'z_dist': z}

        self.z_max = msg.range_max
        self.z_angle_increment = msg.angle_increment
                      

    def get_filtered_lidar_readings(self):
        readings = self.z_readings
        z_max = self.z_max
        z_angle_increment = self.z_angle_increment
        z_filtered_readings = {}
        z_dist_below_max = []
        
        for r_angle_idx in readings.keys():
            z_dist = readings[r_angle_idx]['z_dist']

            if z_dist < z_max: #filter out max reads
                z_dist_below_max.append(z_dist) # for variance calculation
                local_angle = r_angle_idx * z_angle_increment
                z_filtered_readings[r_angle_idx] = {'z_dist': z_dist, 'local_angle': local_angle}

        if len(z_dist_below_max) > 0:
            z_variance = np.var(z_dist_below_max)
        else:
            z_variance = 0
        
        return z_filtered_readings, z_variance
    

    def gaussian_pdf_from_variance(self, dist_squared, sigma_squared):
        sigma_squared = max(sigma_squared, 1e-3)
        q = (1 / np.sqrt(2 * np.pi * sigma_squared)) * np.exp(-dist_squared / (2 * sigma_squared))
        print (f"Q value: {q}")
        return q


    def visualize_particles(self, particles_pose):
        rospy.loginfo(f"Visualizing {len(particles_pose)} particles...")

        particles_arr = PoseArray()
        particles_arr.header = Header()
        particles_arr.header.stamp = rospy.Time.now()
        #particles_arr.header.frame_id = 'map'
        particles_arr.header.frame_id = 'world'


        for p in particles_pose:
            pose = Pose()
            pose.position.x = p['x']
            pose.position.y = p['y']
            pose.position.z = 0.0

            # yaw to grid
            q_x, q_y, q_z, q_w = quaternion_from_euler(0, 0, p['yaw'])
            pose.orientation = Quaternion(q_x, q_y, q_z, q_w)
            particles_arr.poses.append(pose)

        #print (f"Particle pose:{particles_arr.poses[0]}")
        self.pose_array_pub.publish(particles_arr)


    def sample_from_motion_model(self, delta_odometry, pose, 
                                 alpha1, alpha2, alpha3, alpha4):
        """
        The motion model.
        Traditionally, utlizes Odometry and pose to predict next pose
        """
        x = pose['x']
        y = pose['y']
        theta = pose['yaw']
        dlta_trans = delta_odometry['trans'] 
        dlta_rot1 =  delta_odometry['rot1']
        dlta_rot2 = delta_odometry['rot2']
        
        # rotation 1
        rot1_ns_vals = np.sqrt((alpha1 * abs(dlta_rot1)) + (alpha2 * dlta_trans))
        rot1_noise = np.random.normal(0, rot1_ns_vals)
        dlta_hat_rot1 = dlta_rot1 + rot1_noise

        # translation
        trans_ns_vals = np.sqrt((alpha3 * dlta_trans + (alpha4 * (abs(dlta_rot1) + abs(dlta_rot2)))))
        trans_noise = np.random.normal(0, trans_ns_vals)
        dlta_hat_trans = dlta_trans + trans_noise

        # rotation 2
        rot2_ns_vals = np.sqrt((alpha1 * abs(dlta_rot2)) + (alpha2 * dlta_trans))
        rot2_noise = np.random.normal(0, rot2_ns_vals)
        dlta_hat_rot2 = dlta_rot2 + rot2_noise

        # predicted values
        x_prime = x + (dlta_hat_trans * math.cos(theta + dlta_hat_rot1))
        y_prime = y + (dlta_hat_trans * math.sin(theta + dlta_hat_rot1))
        theta_prime = theta + dlta_hat_rot1 + dlta_hat_rot2

        predicted_pose = {'x':x_prime, 'y':y_prime, 'yaw':theta_prime}
        return predicted_pose


    def likelihood_field_range_finder_model(self, likelihood_matrix, pose, resolution):
        """
        The sensor model.
        Traditionally, utilizes the predicted pose and lidar reading and returns a probability
        of lidar reading given pose. Inputs - readings, predicted pose, map 
        """
        # Get filtered lidar readings and their variance
        z_filtered, z_variance = self.get_filtered_lidar_readings()

        # Prevent division by zero or extreme peaking
        if z_variance < 1e-5:
            z_variance = 0.1

        # Parameters for sensor model
        z_hit = 0.9   # weight for correct measurement
        z_rand = 0.2  # weight for random measurements
        q = 1.0
        num_valid = 0

        x = pose['x']
        y = pose['y']
        theta = pose['yaw']

        for z_idx, reading in z_filtered.items():
            z_local_angle = reading['local_angle']
            z_dist_k = reading['z_dist']
            
            global_angle = theta + z_local_angle
            global_angle = (global_angle + np.pi) % (2 * np.pi) - np.pi

            # Compute endpoint in global coordinates
            x_k = x + (z_dist_k * math.cos(global_angle))
            y_k = y + (z_dist_k * math.sin(global_angle))

            # Compute squared distance to nearest obstacle
            distance_sqrd = calculate_distance_squared_from_map(x_k, y_k, likelihood_matrix, resolution)

            # Gaussian model for hit
            p_hit = (1.0 / math.sqrt(2 * math.pi * z_variance)) * math.exp(-0.5 * distance_sqrd / z_variance)
            
            # Uniform random measurement
            p_rand = 1.0 / self.z_max if self.z_max > 0 else 0.0

            p = z_hit * p_hit + z_rand * p_rand
            p = max(p, 1e-10)  # Avoid zero probability
            q *= p
            num_valid += 1

        # If no valid beams, return a small probability
        if num_valid == 0:
            return 1e-10
        return q

    
    def run_particle_filter(self, n_particles, prev_particles_pose, odom_deltas, likelihood_matrix, lm_resolution):
        """
        Particle filter -> predicts the pose of the model based on the motion model and the sensor 
        model 
        """
        temp_predict_pose = [] # [pose, ...]
        temp_predict_weight = [] #[weight, ...]
        alpha1, alpha2, alpha3, alpha4 = 0.05, 0.05, 0.1, 0.1
        #alpha1, alpha2, alpha3, alpha4 = 0.005, 0.005, 0.01, 0.01
        #alpha1, alpha2, alpha3, alpha4 = 0.01, 0.01, 0.01, 0.01

        #alpha1, alpha2, alpha3, alpha4 = 0.05, 0.05, 0.02, 0.02

        #alpha1, alpha2, alpha3, alpha4 = 0, 0, 0, 0


        for pt_idx in range(n_particles):
            prev_pose = prev_particles_pose[pt_idx]

            predicted_pose = self.sample_from_motion_model(odom_deltas, 
                                                            prev_pose,
                                                            alpha1, 
                                                            alpha2, 
                                                            alpha3, 
                                                            alpha4)
            
            predicted_weight = self.likelihood_field_range_finder_model(likelihood_matrix,
                                                                        predicted_pose,
                                                                        lm_resolution)
            temp_predict_pose.append(predicted_pose)
            temp_predict_weight.append(predicted_weight)


        # Normalize probabilties
        temp_predict_weight = np.array(temp_predict_weight)
        if np.sum(temp_predict_weight) == 0:
            temp_predict_weight = np.ones(n_particles) / n_particles  
        else:
            temp_predict_weight = temp_predict_weight / np.sum(temp_predict_weight)

        print (f"WEIGHTs {temp_predict_weight}")

        # resampling step
        new_particle_indices = np.random.choice(range(n_particles), n_particles, p=temp_predict_weight)
        predicted_particles_pose = [temp_predict_pose[ps_idx] for ps_idx in new_particle_indices]

        #return temp_predict_pose
        return predicted_particles_pose

       

    def main(self, metric_map_path, n_particles, resolution):
        """
        Main function 
        """
        try:            
            likelihood_matrix, resolution = extract_from_map(metric_map_path, resolution=resolution, save=False, 
                                                 downsample_factor=2)
            
            prev_particles_pose = self.initialize_particles(n_particles)

            while True:
                odom_deltas, pose = p_filter.calculate_motion_deltas()
                predicted_particles_pose = self.run_particle_filter(n_particles, 
                                                                    prev_particles_pose,
                                                                    odom_deltas,
                                                                    likelihood_matrix,
                                                                    resolution) 


                prev_particles_pose = predicted_particles_pose
                self.visualize_particles(prev_particles_pose)


                # # mean_x = np.mean([p['x'] for p in predicted_particles_pose])
                # # std_x = np.std([p['x'] for p in predicted_particles_pose])
                # # std_y = np.std([p['y'] for p in predicted_particles_pose])
                # # std_theta = np.std([p['yaw'] for p in predicted_particles_pose])  

                # # print(f"Mean X: {mean_x}, Std X: {std_x}, Std Y: {std_y}, Std Theta: {std_theta}")             

                # test_pose = {
                # 'x': self.current_position.x,
                # 'y': self.current_position.y,
                # 'yaw': self.current_yaw
                # }
                # weight = self.likelihood_field_range_finder_model(likelihood_matrix, test_pose, resolution)
                # print(f"[Sensor Model Test] Weight at true pose: {weight}")

                self.rate.sleep()

        except rospy.ROSInterruptException:
            sys.exit(0)



if __name__ == "__main__":
    rate_hz = 5
    #metric_map_path = "../maps/metric_map.pgm"
    #metric_map_yaml = "../maps/metric_map.yaml"

    metric_map_path = "metric_map.pgm"
    metric_map_yaml = "metric_map.yaml"

    n_particles = 100
    n_readings = 30 # no. of beams to read
    map_resolution = 0.05 #meters /pixel 

    p_filter = ParticleFilter(rate_hz, n_readings, metric_map_yaml)
    time.sleep(10) # 1 sec to initialize everything

    p_filter.main(metric_map_path, n_particles, map_resolution)
    #p_filter.main(metric_map_yaml, n_particles, map_resolution)

    rospy.spin()
