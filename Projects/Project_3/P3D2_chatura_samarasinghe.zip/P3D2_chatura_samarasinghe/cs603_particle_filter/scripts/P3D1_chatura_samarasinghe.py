
# import rospy
# import numpy as np
# import math
# from nav_msgs.msg import Odometry
# from tf.transformations import euler_from_quaternion
# from geometry_msgs.msg import Pose, Twist
# from sensor_msgs.msg import LaserScan 

# import generate_likelihood_field

# metric_map_path = '../maps/metric_map.pgm'
# distance_matrix = generate_likelihood_field.extract_from_map(metric_map_path)


# prev_position = Pose()
# prev_yaw = 0
# prev_time = rospy.Time.now()

# dlta_trans = 0
# dlta_rot1 = 0
# dlta_rot2 = 0

# z_reading = None
# max_z = 0

# def odom_callback(msg):
#     global prev_position
#     global prev_orientation
#     global prev_time
#     global dlta_trans
#     global dlta_rot1
#     global dlta_rot2

#     current_position = msg.pose.pose.position
#     current_orientation = msg.pose.pose.orientation
    
#     # Convert quaternion to Euler angles (yaw)
#     _, _, current_yaw = euler_from_quaternion(
#         [current_orientation.x,
#             current_orientation.y,
#             current_orientation.z,
#             current_orientation.w]
#     )
    
#     # Calculate time difference
#     current_time = rospy.Time.now()
#     dt = (current_time - prev_time).to_sec()
    
#     dx = current_position.x - prev_position.x
#     dy = current_position.y - prev_position.y

#     # updating delta values
#     dlta_trans = math.sqrt(dx**2 + dy**2)

#     # TODO: should pre_yaw be abs() here ?
#     dlta_rot1 = math.atan2(dy, dx) - prev_yaw
#     dlta_rot2 = current_yaw - prev_yaw - dlta_rot1


#     # Calculate velocities (alternative method)
#     prev_position = current_position
#     prev_yaw = current_yaw
#     prev_time = current_time

# def lidar_callback(msg):
#     global z_readings
#     global max_z

#     max_z = msg.range_max
#     z_readings = msg.data.ranges



# # motion model 
# def sample_from_motion_model(pose, alpha1, alpha2, alpha3, alpha4 ):

# #def sample_from_motion_model(u, pose, alpha1, alpha2, alpha3, alpha4 ):
#     # Q: Are we using the pose at the current time step?
#     # Q: Where are the alpha values coming from?


#     # TODO: get the pose reading 
#     x = pose.x
#     y = pose.y
#     theta = pose.theta

#     # rotation 1
#     rot1_ns_vals = (alpha1 * abs(dlta_rot1)) + (alpha2 * dlta_trans)
#     rot1_noise = np.random.normal(rot1_ns_vals)
#     dlta_hat_rot1 = dlta_rot1 + rot1_noise

#     # translation
#     trans_ns_vals = (alpha3 * dlta_trans + (alpha4 * (abs(dlta_rot1) + abs(dlta_rot2))))
#     trans_noise = np.random.normal(trans_ns_vals)
#     dlta_hat_trans = dlta_trans + trans_noise

#     # rotation 2
#     rot2_ns_vals = (alpha1 * abs(dlta_rot2)) + (alpha2 * dlta_trans)
#     rot2_noise = np.random.normal(rot2_ns_vals)
#     dlta_hat_rot2 = dlta_rot2 + rot2_noise

#     x_prime = x + (dlta_hat_trans * math.cos(theta + dlta_hat_rot1))
#     y_prime = y + (dlta_hat_trans * math.sin(theta + dlta_hat_rot1))
#     theta_prime = theta + dlta_hat_rot1 + dlta_hat_rot2

#     return x_prime, y_prime, theta_prime


# # sensor model

# #def likelihood_field_range_finder_model(z_t, pose_t, m):
# def likelihood_field_range_finder_model(pose_t):
#     q = 1 
#     z_max = max_z
    
#     #pose at t
#     x = pose_t.x
#     y = pose_t.y
#     theta = pose_t.theta

#     #z_reading = None # lidar valesu

#     for z_k in z_reading:
#         if z_k < z_max:
#             x_k = 0 # check if these values must be kept 0
#             y_k = 0 # check if these values must be kept 0
#             theta_k = 0 # check if these values must be kept 0
            
#             x_endpoint = x + (x_k * math.cos(theta)) - (y_k * math.sin(theta)) + z_k * math.cos(theta + theta_k)
#             y_endpoint = y + (y_k * math.cos(theta)) - (x_k * math.sin(theta)) + z_k * math.sin(theta + theta_k)

#             distance =  generate_likelihood_field.calculate_distance(
#                 x_endpoint, 
#                 y_endpoint, 
#                 distance_matrix, 
#                 resolution=0.05)
            
#             std_dev = 1 #where do to find this value?
#             # Q: should the distance be squared 
#             prob = np.random.normal(distance, std_dev)
#             q = q * prob
        
#     return q


# odom_reading = rospy.Subscriber('/odom', Odometry, odom_callback)
# radar_subscriber = rospy.Subscriber('/scan', LaserScan, lidar_callback)
