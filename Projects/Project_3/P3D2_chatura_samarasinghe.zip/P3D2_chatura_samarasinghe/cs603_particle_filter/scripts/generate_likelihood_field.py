#!/usr/bin/env python3

# Write your code here

import cv2
import numpy as np
import os


def extract_from_map(image_path, resolution=0.05, save=False, downsample_factor=2):
    """
    Extract likelihood field from map image.
    - resolution: original resolution (m/pixel)
    - downsample_factor: factor to reduce resolution (2 = half size)
    """

    script_dir = os.path.dirname(os.path.abspath(__file__))
    image_path = os.path.join(script_dir, image_path)

    #image_path = os.path.abspath(image_path)

    # Load grayscale image
    map_image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Binarize: obstacles = 0, free = 255
    _, binary_map = cv2.threshold(map_image, 250, 255, cv2.THRESH_BINARY)

    # Clean noise
    kernel = np.ones((3,3), np.uint8)
    cleaned_map = cv2.morphologyEx(binary_map, cv2.MORPH_OPEN, kernel)

    # Compute distance transform
    distance_matrix = cv2.distanceTransform(cleaned_map, cv2.DIST_L2, 5)
    real_world_distances = distance_matrix * resolution

    if downsample_factor > 1:
        new_size = (real_world_distances.shape[1] // downsample_factor,
                    real_world_distances.shape[0] // downsample_factor)
        real_world_distances = cv2.resize(real_world_distances, new_size, interpolation=cv2.INTER_AREA)
        resolution *= downsample_factor  # each pixel now covers a larger area

    # Visualization
    gamma = 0.4
    scaled = (real_world_distances / real_world_distances.max()) ** gamma
    visualization = (scaled * 255).astype(np.uint8)

    if save:
        cv2.imwrite('../maps/metric_map.png', map_image)
        cv2.imwrite('../maps/distance_matrix.png', visualization)

    # cv2.imshow('Likelihood Field', visualization)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

    return real_world_distances, resolution



def calculate_distance_squared_from_map(x_pos, y_pos, lookup_matrix, resolution):
    origin_x, origin_y = -10.0, -10.0 # hard coded
    
    # Convert particle pose to map coordinates

    height, width = lookup_matrix.shape

    x_map = int((x_pos - origin_x)/ resolution)
    #x_map = width - int((x_pos - origin_x)/ resolution) -1

    y_map = height - int((y_pos - origin_y)/ resolution) -1 
    #y_map = int((y_pos - origin_y)/ resolution)


    # # Out of bounds check
    # if x_map < 0 or x_map >= width or y_map < 0 or y_map >= height:
    #     return 1e6   
    
    # maps to downsampled res of 2 
    # if x_map < 24 or x_map >= 168 or y_map < 40 or y_map >= 91:
    #     return 4**2   
    
    ## maps to downsampled res of 2 
    if x_map < 24 or x_map >= 168 or y_map < 37 or y_map >= 126:
        return 4**2 

    ## check for middle gap
    elif (x_map > 51 and x_map < 140) and (y_map > 95):
        return 4**2 

    
    # Get expected distance from distance matrix
    expected_distance = lookup_matrix[y_map, x_map]
    
    # Compare with sensor measurements
    return expected_distance ** 2 

#image_path = '../maps/metric_map.pgm'
#extract_from_map(image_path)